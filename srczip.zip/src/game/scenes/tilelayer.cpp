#include "../../core/gamedefs.h"


TileLayer::TileLayer() {
    

}

TileLayer::~TileLayer() {

}


void TileLayer::Update() {

}

void TileLayer::Draw() {

}


bool CollideAndSlide(BaseEntity *checker, CollisionResult &collision_result, Vector2 ckeck_position) {
    //================TILE COLLISION=========================
    //TraceLog(LOG_INFO, "collide and slide  checker pos %0.0f, %0.0f", ckeck_position.x, ckeck_position.y);
    bool collided = false;

    LevelData *level_data = nullptr;

    if(g_game_data.is_in_sub_map) {
        level_data = &g_sub_scene->level_data;
    }
    else {
        level_data = &g_current_scene->level_data;
    }

    if(level_data == nullptr) {
        return -1;
    }
    //TraceLog(LOG_INFO, "level data found");

    LDTKLevel &this_level = g_ldtk_maps.levels[level_data->precalc.map_index];

    //TraceLog(LOG_INFO, "level %s", this_level.identifier.c_str());

    if(level_data->precalc.collision_layer_index == -1) {
        //TraceLog(LOG_INFO, "no collision layer");
        return false;
    }
    
    LDTKLayerInstance &col_layer = this_level.layer_instances[level_data->precalc.collision_layer_index];
    //TraceLog(LOG_INFO, "collision layer %s %i", this_level.layer_instances[level_data->precalc.collision_layer_index].identifier.c_str(), level_data->precalc.collision_layer_index);

    int tile_size = level_data->precalc.tile_size;
    float inv_tile_size = level_data->precalc.inv_tile_size;
    int map_width = level_data->precalc.map_width;

    Vector2 checker_pos = ckeck_position;


    int cell_pos_x_i = (ckeck_position.x + checker->centered_offset.x) * inv_tile_size;
    int cell_pos_y_i = (ckeck_position.y+ checker->centered_offset.y) * inv_tile_size;


    float c_rad = checker->collision_radius;
    
    int left_i = (checker_pos.x - c_rad) * inv_tile_size;
    int right_i = (checker_pos.x + c_rad) * inv_tile_size;
    int top_i = (checker_pos.y - c_rad) * inv_tile_size;
    int bottom_i = (checker_pos.y + c_rad) * inv_tile_size;

    //TraceLog(LOG_INFO, "checker pos %i, %i", c_pos_x_i, c_pos_y_i);

    //check x direction
    //left
    int index = cell_pos_y_i * map_width + left_i;
    int value = col_layer.int_grid[index];
    //TraceLog(LOG_INFO, "checking l %i, %i  | index %i   | value %i", left_i, c_pos_y_i , index, value);
    if(value == 1 or value == 2) {
        if(CheckCollisionCircleRec( checker_pos, c_rad, { (float)left_i * tile_size, (float)cell_pos_y_i * tile_size, (float)tile_size, (float)tile_size } )) {
            //TraceLog(LOG_INFO, "COLLISON LEFT");
            collision_result.collision_dir.x = -1;
            collided =  true;
        }
    }
    //right
    index = cell_pos_y_i * map_width + right_i;
    value = col_layer.int_grid[index];
    //TraceLog(LOG_INFO, "checking r %i, %i  | index %i   | value %i", right_i, c_pos_y_i , index, value);
    if(value == 1 or value == 2) {
        if(CheckCollisionCircleRec( checker_pos, c_rad, { (float)right_i * tile_size, (float)cell_pos_y_i * tile_size, (float)tile_size, (float)tile_size } )) {
            //TraceLog(LOG_INFO, "COLLISON RIGHT");
            collision_result.collision_dir.x = 1;
            collided =  true;
        }
    }
    //check y direction
    //top
    index = top_i * map_width + cell_pos_x_i;
    value = col_layer.int_grid[index];
    //TraceLog(LOG_INFO, "checking t %i, %i  | index %i   | value %i", c_pos_x_i, top_i , index, value);
    if(value == 1 or value == 2) {
        if(CheckCollisionCircleRec( checker_pos, c_rad, { (float)cell_pos_x_i * tile_size, (float)top_i * tile_size, (float)tile_size, (float)tile_size } )) {
            //TraceLog(LOG_INFO, "COLLISON TOP");
            collision_result.collision_dir.y = -1;
            collided =  true;
        }
    }
    //bottom
    index = bottom_i * map_width + cell_pos_x_i;
    value = col_layer.int_grid[index];

    //TraceLog(LOG_INFO, "checking b %i, %i  | index %i   | value %i", c_pos_x_i, bottom_i, index, value);
    if(value == 1 or value == 2) {
        if(CheckCollisionCircleRec( checker_pos, c_rad, { (float)cell_pos_x_i * tile_size, (float)bottom_i * tile_size, (float)tile_size, (float)tile_size } )) {
            //TraceLog(LOG_INFO, "COLLISON BOTTOM");
            collision_result.collision_dir.y = 1;
            collided =  true;
        }
    }
    //TraceLog(LOG_INFO, "\n");
    return collided;
}



bool CollideWithTile(BaseEntity *checker, CollisionResult &collision_result) {
    
    bool collided = false;

    LevelData *level_data = nullptr;

    if(g_game_data.is_in_sub_map) {
        level_data = &g_sub_scene->level_data;
    }
    else {
        level_data = &g_current_scene->level_data;
    }

    if(level_data == nullptr) {
        return -1;
    }

    LDTKLevel &this_level = g_ldtk_maps.levels[level_data->precalc.map_index];

    if(level_data->precalc.collision_layer_index == -1) {
        return false;
    }
    LDTKLayerInstance &col_layer = this_level.layer_instances[level_data->precalc.collision_layer_index];


    int tile_size = level_data->precalc.tile_size;
    float inv_tile_size = level_data->precalc.inv_tile_size;
    int map_width = level_data->precalc.map_width;

    Vector2 checker_pos = Vector2Add(checker->position, checker->centered_offset);

    int cell_pos_x_i = (checker->position.x + checker->centered_offset.x) * inv_tile_size;
    int cell_pos_y_i = (checker->position.y + checker->centered_offset.y) * inv_tile_size;

    int cell = (checker_pos.x) * inv_tile_size;
    int index = cell_pos_y_i * map_width + cell;
    int value = col_layer.int_grid[index];

    if(value == 1) {
        //if(CheckCollisionCircleRec( {1,1}, 0.1, {10,10,1,1})) {
        TraceLog(LOG_INFO, "radius %f", checker->collision_radius);
        if(CheckCollisionCircleRec( checker_pos, checker->collision_radius, { (float)cell_pos_x_i * tile_size, (float)cell_pos_y_i * tile_size, (float)tile_size, (float)tile_size } )) {
            collided =  true;
        }
    }

    return collided;
}






void DrawMapGenDebugVisuals(LevelData &level_data) {
    if(!g_debug_data.show_poi_layer) {
        return;
    }

    int ts = level_data.precalc.tile_size;

    

    for(InfluenceCell cell : g_debug_plan.influence_grid) {
        Color color = BLANK;
        
        if(g_debug_data.poi_layer == 0) {
            color.r = cell.road * 150;
            color.a = 255;
        }
        if(g_debug_data.poi_layer == 1) {
            color.g = cell.center * 150;
            color.a = 255;
        }
        if(g_debug_data.poi_layer == 2) {
            color.b = cell.edge * 150;
            color.a = 255;
        }
        if(g_debug_data.poi_layer == 3) {
            color.b = cell.forrest * 150;
            color.g = cell.forrest * 150;
            color.a = 255;
        }

        
        DrawRectangle(cell.rect.x * ts, cell.rect.y * ts, cell.rect.width * ts, cell.rect.height * ts, color);
        DrawRectangleLines(cell.rect.x * ts, cell.rect.y * ts, cell.rect.width * ts, cell.rect.height * ts, DARKERGRAY);
    }

    for(StructurePatch patch : g_debug_plan.poi_patches) {
        //Rectangle rect = patch.rect;
        DrawRectangle((patch.rect.x + 1) * ts, (patch.rect.y + 1) * ts, (patch.rect.width - 2) * ts, (patch.rect.height - 2) * ts, DARKGREEN);
    }

    for(Rectangle rect : g_debug_plan.reserved_rects) {
        //Rectangle rect = patch.rect;
        DrawRectangleLines((rect.x * ts) - 1, (rect.y * ts) - 1, (rect.width * ts) + 2, (rect.height * ts) + 2, GOLD);
    }

    DrawRectangle(g_debug_plan.road_midpoint.x * ts, g_debug_plan.road_midpoint.y * ts, 2 * ts, 2 * ts, WHITE);

    for(Vector2 &con_pos : g_debug_plan.connected_positions) {
        DrawRectangle(con_pos.x * ts, con_pos.y * ts, 2 * ts, 2 * ts, WHITE);
    }
}
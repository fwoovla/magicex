#pragma once 
#include "gamedefs.h"
#include "baseentity.h"

struct ModuleData {
    ModuleID module_id;
    std::string module_name;
    std::vector<int> recipies;
    std::vector<int> accepted_plans;

};

extern std::vector<ModuleData> g_module_data;

class BaseModuleEntity : public SpriteEntity {
    public:

    ~BaseModuleEntity() = default;
    virtual void OnModuleUsed() = 0;
    

    std::string iid;
    int level_index = 0;
    int loot_table_id = 0;
    int module_id = 0;
    bool is_open = false;
    
    ModuleArea m_area;

    Signal open_module;

    RayCast raycast;

};

class ModuleEntity : public BaseModuleEntity {
    public:
    ModuleEntity(Vector2 position, int _module_id);
    ~ModuleEntity() override;
    void Update() override;
    void Draw() override;
    void DrawUI() override;
    void OnModuleUsed() override;
    float GetYSort() override;
    void TakeDamage(DamagePayload _payload) override;};
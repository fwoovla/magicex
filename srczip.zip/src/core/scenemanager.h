#pragma once

#include "gamedefs.h"


extern std::unique_ptr<BaseScene> g_current_scene;
extern std::unordered_map<std::string, std::unique_ptr<LevelData>> g_sub_scene_data;
extern std::unique_ptr<SubScene> g_sub_scene;

extern std::unordered_map<std::string, std::unique_ptr<SubSceneState>> g_sub_scene_state;

void InstanceLevelObjects(LevelData &level_data);

class SceneManager{
    public:
    void Init();
    void CleanUp();
    void UpdateScene();
    void DrawScene();
    void DrawUI();
    void ChangeSceneTo(SCENE_ID new_scene_id);
    void TransitionSceneTo(SCENE_ID new_scene_id);

    
    void OnPausePressed();
    void OnSavePressed();
    void OnBackToMenuPressed();
    void OnQuitPressed();

/*     void OnTransitionEnded();
    void OnTransitionMidpoint(); */

    /* std::unique_ptr<BaseScene> current_scene; */
    //BaseScene *current_scene;
    std::unique_ptr<PauseMenu> pause_menu;

    std::unique_ptr<FadeTransition> fade_transition;

    bool is_transitioning;
    bool can_delete_transition;

    SCENE_ID next_scene_id;

    Label debug_label;

        //bool paused;

    private:
};


/* void InstanceSavedObjects(LevelData &level_data);

void InstanceNewObjects(LevelData &level_data); */